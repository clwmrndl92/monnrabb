import pygame as pg
import sys
import math
import random
import os

os.environ['SDL_VIDEO_WINDOW_POS'] = "{},{}".format(50, 50)
pg.init()
pg.font.init()
game_font = pg.font.SysFont('MalgunGothic', 25)

clock = pg.time.Clock()
"""COLOR_RED = pg.Color(255,0,0)
COLOR_BLUE = pg.Color(0,0,255)"""
COLOR_BLACK = pg.Color(0, 0, 0)
COLOR_WHITE = pg.Color(255, 255, 255)

SOUND_Hecklebot = pg.mixer.Sound('./kill.wav')
pg.mixer.music.load('./music.ogg')
pg.mixer.music.play(loops=-1)
pg.mixer.music.set_volume(0.5)

Screen = (1000, 500)
moonsize = (2000, 2000)
phase_size = (200, 200)
rabbitsize = (170, 120)
playersize = (200, 200)
speed = 8
FPS = 70
rabbitnum = 0
SAKSKILL1 = False
SAKSKILL1_ON = False
SAKSKILL2 = True
SAKSKILL2_ON = False

moon_phase_images = []
for i in range(12):
    moon_phase_images.append(pg.transform.scale(pg.image.load('./moonphase/moonphase%d.png' % i), phase_size))
rabbit_images = [pg.image.load('./rabbit_0.png'), pg.image.load('./rabbit_1.png'),pg.image.load('./삭스킬.png')]
fullmoon_images = [pg.image.load('./moon_1.png'), pg.image.load('./moon_0.png')]
sakskill_1_images = [pg.image.load('./null.png'), pg.image.load('./삭배경_1.png')]
ooraskill_images = [pg.image.load('./null.png'), pg.image.load('./oora3.png')]
clear_images = []
for i in range(4):
    clear_images.append(pg.transform.scale(pg.image.load('./clear%d.png' % i), Screen))
user = pg.image.load('./user.png')

DISPLAY = pg.display.set_mode(Screen)


class displays(pg.sprite.Sprite):
    def __init__(self):
        pg.sprite.Sprite.__init__(self)
        self.image = pg.transform.scale(pg.image.load('./image08.jpg'), moonsize)
        self.rect = self.image.get_rect()
        self.rect.center = (Screen[0] / 2, Screen[1] / 2)
        # self.x_acc = 0
        # self.y_acc = 0
        displays.x_position = self.rect.x
        displays.y_position = self.rect.y
        self.mask = pg.mask.from_surface(self.image)

    def update(self):
        key = pg.key.get_pressed()

        if key[pg.K_LEFT] and displays.x_position < -5 and player.x_center == Screen[0] / 2:
            displays.x_position += speed
        if key[pg.K_RIGHT] and displays.x_position + moonsize[0] > Screen[0] + 5 and player.x_center == Screen[0] / 2:
            displays.x_position -= speed
        if key[pg.K_DOWN] and displays.y_position + moonsize[1] > Screen[1] + 5 and player.y_center == Screen[1] / 2:
            displays.y_position -= speed
        if key[pg.K_UP] and displays.y_position < -5 and player.y_center == Screen[1] / 2:
            displays.y_position += speed
        self.rect.x = displays.x_position
        self.rect.y = displays.y_position

class player(pg.sprite.Sprite):
    def __init__(self):
        pg.sprite.Sprite.__init__(self)
        self.image = pg.transform.scale(user, playersize)
        self.image.blit(pg.transform.scale(ooraskill_images[0], playersize), (0, 0))
        self.rect = self.image.get_rect()
        self.rect.center = (Screen[0] / 2, Screen[1] / 2)
        player.x_position = self.rect.x
        player.y_position = self.rect.y
        player.x_center = self.rect.centerx
        player.y_center = self.rect.centery
        self.mask = pg.mask.from_surface(self.image)

    def update(self):
        key = pg.key.get_pressed()
        if (key[pg.K_LEFT] and displays.x_position >= -5 and self.x_position > -40) or (
                key[pg.K_LEFT] and player.x_center > Screen[0] / 2):
            self.x_position -= speed
            player.x_center -= speed
        if (key[pg.K_RIGHT] and displays.x_position + moonsize[0] <= Screen[0] + 5 and self.x_position + playersize[0] <
            Screen[0] + 40) or (key[pg.K_RIGHT] and player.x_center < Screen[0] / 2):
            self.x_position += speed
            player.x_center += speed
        if (key[pg.K_DOWN] and displays.y_position + moonsize[1] <= Screen[1] + 5 and self.y_position + playersize[1] <
            Screen[1] + 51) or (key[pg.K_DOWN] and player.y_center < Screen[1] / 2):
            self.y_position += speed
            player.y_center += speed
        if (key[pg.K_UP] and displays.y_position >= -5 and self.y_position > -30) or (
                key[pg.K_UP] and player.y_center > Screen[1] / 2):
            self.y_position -= speed
            player.y_center -= speed
        if SAKSKILL2_ON == True:
            self.image = pg.transform.scale(ooraskill_images[1], (playersize[0] + 150, playersize[1] + 150))
            self.image.blit(pg.transform.scale(user, playersize),(75,75))
            self.mask = pg.mask.from_surface(self.image)
        elif SAKSKILL2_ON == False:
            self.image = pg.transform.scale(user, playersize)
            self.image.blit(pg.transform.scale(ooraskill_images[0], playersize), (0, 0))
        self.rect.x = player.x_position
        self.rect.y = player.y_position
        self.rect.centerx = player.x_center
        self.rect.centery = player.y_center


class Rabbit(pg.sprite.Sprite):
    def __init__(self, player):
        pg.sprite.Sprite.__init__(self)
        if SAKSKILL1_ON == False:
            self.image = pg.transform.scale(sakskill_1_images[0], rabbitsize)
            self.image.blit(pg.transform.scale(rabbit_images[1], rabbitsize), (0,0))
        elif SAKSKILL1_ON == True:
            self.image = pg.transform.scale(rabbit_images[2], rabbitsize)
            self.image.blit(pg.transform.scale(rabbit_images[1], rabbitsize), (0, 0))
        self.rect = self.image.get_rect()
        self.rect.center = (random.randint(0, Screen[0]), random.randint(0, Screen[1]))
        self.y_position = self.rect.y
        self.x_position = self.rect.x
        self.speedx = 5 * random.uniform(-1,1)
        self.speedy = 5 * random.uniform(-1,1)
        self.mask = pg.mask.from_surface(self.image)
        self.player = player
        self.dead = False

    def update(self):
        global rabbitnum
        key = pg.key.get_pressed()
        ispressed = False

        if key[pg.K_SPACE]:
            ispressed = True
        if key[pg.K_LEFT] and player.x_center == Screen[0] / 2:
            self.x_position += speed
        if key[pg.K_RIGHT] and player.x_center == Screen[0] / 2:
            self.x_position -= speed
        if key[pg.K_DOWN] and player.y_center == Screen[1] / 2:
            self.y_position -= speed
        if key[pg.K_UP] and player.y_center == Screen[1] / 2:
            self.y_position += speed

        if not self.dead and ispressed and math.hypot(self.x_position + 85 - player.x_center,
                                                      self.y_position + 60 - player.y_center) <= 100:
            SOUND_Hecklebot.play(loops=0)
            self.dead = True
            rad = math.atan2(self.y_position + 60 - Screen[1], self.x_position + 85 - Screen[0])
            self.speedx -= math.cos(rad) * 50
            self.speedy -= math.sin(rad) * 50
            rabbitnum += 1

        if SAKSKILL1_ON == True:
            self.image = pg.transform.scale(rabbit_images[2], rabbitsize)
            self.image.blit(pg.transform.scale(rabbit_images[1], rabbitsize),(0,0))
        elif SAKSKILL1_ON == False:
            self.image = pg.transform.scale(sakskill_1_images[0], rabbitsize)
            self.image.blit(pg.transform.scale(rabbit_images[1], rabbitsize), (0,0))
        if SAKSKILL2_ON ==True:
            if pg.sprite.collide_mask(self, self.player):
                SOUND_Hecklebot.play(loops=0)
                self.dead = True
                rad = math.atan2(self.y_position + 60 - Screen[1], self.x_position + 85 - Screen[0])
                self.speedx -= math.cos(rad) * 50
                self.speedy -= math.sin(rad) * 50
                rabbitnum += 1

        self.y_position += self.speedy
        self.rect.y = self.y_position
        self.x_position += self.speedx
        self.rect.x = self.x_position
        if self.rect.centery > Screen[1] + 300 or self.rect.centerx > Screen[
            0] + 300 or self.rect.centerx < -300 or self.rect.centery < -300:
            self.kill()

score_bar_surface = pg.Surface((210, 250))
score_bar_rect = pg.draw.rect(score_bar_surface, (0, 0, 0), (0, 0, 210, 150))
score_bar_rect.topleft = (Screen[0] - 210, Screen[1] - 250)
moon_phase_image = pg.transform.scale(moon_phase_images[0], phase_size)
moon_phase_rect = moon_phase_image.get_rect()
moon_phase_rect.center = (Screen[0] - 100, Screen[1] - 100)
sakskill_1_image = pg.transform.scale(sakskill_1_images[0], (phase_size[0] // 2,phase_size[1] // 2))
sakskill_1_rect = sakskill_1_image.get_rect()
sakskill_1_rect.center = (Screen[0] - 104, Screen[1] - 104)
ooraskill_image = pg.transform.scale(ooraskill_images[0], (phase_size[0] // 2,phase_size[1] // 2))
ooraskill_rect = ooraskill_image.get_rect()
ooraskill_rect.center = (Screen[0] - 99, Screen[1] - 99)
fullmoon_image = pg.transform.scale(fullmoon_images[0], (phase_size[0] // 2,phase_size[1] // 2))
fullmoon_rect = fullmoon_image.get_rect()
fullmoon_rect.center = (Screen[0] - 100, Screen[1] - 100)
clear_image = clear_images[0]
clear_rect = clear_image.get_rect()
clear_rect.center = (Screen[0] // 2, Screen[1] // 2)

fail = False
Clear = False
limit = 0
cooltime = 0
moonphase = 0
sakskill_1 = 0
ooraskill = 0
clear1 = 0
clear2 = 0
pg.time.set_timer(pg.USEREVENT, 800)
pg.time.set_timer(pg.USEREVENT+1, 1500)
pg.time.set_timer(pg.USEREVENT+2, 500)
pg.time.set_timer(pg.USEREVENT+3, 2000)
pg.time.set_timer(pg.USEREVENT+4, 1000)
player = player()
player_Group = pg.sprite.Group()
player_Group.add(player)
displays = displays()
displays_Group = pg.sprite.Group()
displays_Group.add(displays)
enemy_Group = pg.sprite.Group()

while True:
    if Clear == True:
        for event in pg.event.get():
            if event.type == pg.QUIT:
                pg.quit()
                sys.exit()
            if event.type == pg.USEREVENT + 2 and clear2 < 2:
                clear1 += 1
                clear_image = clear_images[clear1 % 4]
                clear_rect = clear_image.get_rect()
                clear_rect.center = (Screen[0] // 2, Screen[1] // 2)
            if event.type == pg.USEREVENT + 3:
                clear2 +=1
                if clear2 == 2:
                    clear_image = pg.transform.scale(pg.image.load('./end.png'), Screen)
                elif clear2 > 3:
                    pg.quit()
                    sys.exit()

        DISPLAY.fill(COLOR_BLACK)

        DISPLAY.blit(clear_image, clear_rect)

        pg.display.flip()
        clock.tick_busy_loop(FPS)

        continue
    if fail == True:
        for event in pg.event.get():
            if event.type == pg.QUIT:
                pg.quit()
                sys.exit()
            if event.type == pg.USEREVENT + 4:
                limit += 1
                if limit >= 105:
                    pg.quit()
                    sys.exit()
        dead_image = pg.transform.scale(pg.image.load('./dead.png'), Screen)
        dead_rect = clear_image.get_rect()
        dead_rect.center = (Screen[0] // 2, Screen[1] // 2)

        DISPLAY.fill(COLOR_BLACK)

        DISPLAY.blit(dead_image, dead_rect)

        pg.display.flip()
        clock.tick_busy_loop(FPS)

        continue

    for event in pg.event.get():
        if event.type == pg.QUIT:
            pg.quit()
            sys.exit()
        if event.type == pg.USEREVENT + 4:
            limit += 1
            if limit >= 100:
                fail = True

        if event.type == pg.USEREVENT:
            enemy_Group.add(Rabbit(player))
        if event.type == pg.USEREVENT+1:
            moonphase += 1
            moon_phase_image = moon_phase_images[moonphase%12]
            moon_phase_rect = moon_phase_image.get_rect()
            moon_phase_rect.center = (Screen[0] - 100, Screen[1] - 100)
            if moonphase % 12 == 0:
                PHASE0 = False
                PHASE1 = True
                SAKSKILL1 = False
                SAKSKILL2 = True
                fullmoon_image = pg.transform.scale(fullmoon_images[0], (phase_size[0] // 2, phase_size[1] // 2))
            elif moonphase % 12 == 6:
                PHASE0 = True
                PHASE1 = False
                SAKSKILL1 = True
                SAKSKILL2 = False
                fullmoon_image = pg.transform.scale(fullmoon_images[1], (phase_size[0] // 2, phase_size[1] // 2))
        if SAKSKILL1 == True:
            if event.type == pg.USEREVENT+2:
                sakskill_1 += 1
                sakskill_1_image = pg.transform.scale(sakskill_1_images[sakskill_1 % 2], (phase_size[0] // 2 + 9, phase_size[1] // 2 + 9))
        if SAKSKILL2 == True:
            if event.type == pg.USEREVENT+2:
                ooraskill += 1
                ooraskill_image = pg.transform.scale(ooraskill_images[ooraskill % 2], (phase_size[0] // 2 - 5 , phase_size[1] // 2 - 5))
        if SAKSKILL1_ON == True:
            if event.type == pg.USEREVENT + 3:
                cooltime +=1
                if cooltime > 2:
                    SAKSKILL1_ON = False
                    cooltime = 0
        if SAKSKILL2_ON == True:
            if event.type == pg.USEREVENT + 3:
                cooltime +=1
                if cooltime > 2:
                    SAKSKILL2_ON = False
                    cooltime = 0

    if SAKSKILL1 == True and pg.key.get_pressed()[pg.K_z]:
        SAKSKILL1 = False
        SAKSKILL1_ON = True
        sakskill_1_image = pg.transform.scale(sakskill_1_images[0],
                                              (phase_size[0] // 2, phase_size[1] // 2))
    if SAKSKILL2 == True and pg.key.get_pressed()[pg.K_x]:
        SAKSKILL2 = False
        SAKSKILL2_ON = True
        ooraskill_image = pg.transform.scale(ooraskill_images[0],
                                              (phase_size[0] // 2, phase_size[1] // 2))

    score_text_surface = game_font.render('Rabbit ' + str(rabbitnum) + ' / 100', True, (255, 255, 255))
    score_text_rect = score_text_surface.get_rect()
    score_text_rect.center = (Screen[0] - 100, Screen[1] - 230)
    score_text1_surface = game_font.render('Time : %d' %(100-limit), True, (255, 255, 255))
    score_text1_rect = score_text_surface.get_rect()
    score_text1_rect.center = (Screen[0] - 80, Screen[1] - 200)

    DISPLAY.fill(COLOR_BLACK)

    #if Clear == False:
    enemy_Group.update()
    displays.update()
    player.update()

    if rabbitnum >= 100:
        Clear = True

    displays_Group.draw(DISPLAY)
    enemy_Group.draw(DISPLAY)
    player_Group.draw(DISPLAY)

    DISPLAY.blit(score_bar_surface, score_bar_rect)
    DISPLAY.blit(score_text_surface, score_text_rect)
    DISPLAY.blit(score_text1_surface, score_text1_rect)
    DISPLAY.blit(moon_phase_image, moon_phase_rect)
    DISPLAY.blit(sakskill_1_image, sakskill_1_rect)
    DISPLAY.blit(ooraskill_image, ooraskill_rect)
    DISPLAY.blit(fullmoon_image, fullmoon_rect)

    pg.display.flip()
    clock.tick_busy_loop(FPS)